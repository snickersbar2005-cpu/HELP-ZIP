ZIP'S RUN - ANDROID TABLET PROJECT

This is an Android Studio project that wraps the tablet HTML game in a full-screen
Android WebView. It is not itself an APK.

BUILD AN APK:
1. Install Android Studio on a computer.
2. Open this folder (the one containing settings.gradle) in Android Studio.
3. Allow Gradle sync and install the Android SDK platform requested by the project.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location when the build finishes.

The app is configured for landscape tablets and includes the game locally, so it
does not need an internet connection to load the game.
